<?php
session_start();
if(isset($_POST['logout']))
{
    session_unset();
    session_destroy();
    // header("Cache-Control: no-cache, must-revalidate");
    header('location:index.php');
//     echo "<script>
//     history.pushState(null, null, null);
//     window.addEventListener('popstate', function () {
//         history.pushState(null, null, null);
//     });
// </script>";
}
?>