<br>
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>&copy; Anjana Infotech | All rights reserved <?php echo date('Y'); ?></span>
        </div>
    </div>
</footer>